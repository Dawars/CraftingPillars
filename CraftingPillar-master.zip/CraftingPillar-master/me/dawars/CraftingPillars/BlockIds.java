package me.dawars.CraftingPillars;

public class BlockIds
{
	public static int idExtendPillar = 2005;
	public static int idShowOffPillar = 2006;
	public static int idCraftingPillar = 2007;
	public static int idFurnacePillar = 2008;
	public static int idAnvilPillar = 2009;
	public static int idTankPillar = 2010;
	public static int idBrewingPillar = 2011;
}