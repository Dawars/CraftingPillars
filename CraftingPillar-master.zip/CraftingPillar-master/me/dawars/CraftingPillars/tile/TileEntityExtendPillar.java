package me.dawars.CraftingPillars.tile;

import net.minecraft.tileentity.TileEntity;

public class TileEntityExtendPillar extends TileEntity
{
	
}
