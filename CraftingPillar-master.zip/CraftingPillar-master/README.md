CraftingPillar
==============

Fancy crafting for Minecraft (SMP)

Check out the forum post at: http://www.minecraftforum.net/topic/2046867-162164-crafting-pillar-mod-make-crafting-look-better-smp-support/
